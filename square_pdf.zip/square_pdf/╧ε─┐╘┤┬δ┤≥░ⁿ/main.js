const { app, BrowserWindow, ipcMain, dialog } = require('electron');

let win;

function createWindow() {
  win = new BrowserWindow({
    width: 1000,
    height: 800,
    frame: false,             // 彻底无边框
    transparent: true,        // 透明
    alwaysOnTop: false,        // 保持置顶
    resizable: true,
    backgroundColor: '#00000000',
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      webSecurity: false,      // 允许读取本地 PDF
      plugins: true,           // 开启 PDF 支持
      zoomFactor: 1.0          // 强制初始缩放为 100%
    }
  });

  win.loadFile('index.html');

  // 监听透明度修改
  ipcMain.on('set-opacity', (e, val) => {
    win.setOpacity(Number(val));
  });

  // 打开文件对话框
  ipcMain.on('open-file', (event) => {
    dialog.showOpenDialog(win, {
      properties: ['openFile'],
      filters: [{ name: 'PDF', extensions: ['pdf'] }]
    }).then(result => {
      if (!result.canceled) {
        // 核心：#toolbar=0 隐藏内置黑条，scrollbar=1 保留滚动条方便阅读
        const pdfPath = `file://${result.filePaths[0]}#toolbar=0&navpanes=0&scrollbar=1`;
        event.reply('selected-file', pdfPath);
      }
    });
  });
}

// 强制处理高分屏缩放问题
app.commandLine.appendSwitch('high-dpi-support', '1');
app.commandLine.appendSwitch('force-device-scale-factor', '1');

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());